import * as Baileys from '@whiskeysockets/baileys'
import qrcode from 'qrcode-terminal'
import { boasVindas, comandoBase, nomeBot, podeUsar, prefixo } from './moreira.mjs'
import pino from 'pino'
import fs from 'fs'
import os from 'os'
import path from 'path'
import { fileURLToPath } from 'node:url'
import {
  aplicarPatchEncode, montarCampo134, verificarFfmpeg,
  temAudio, duracao, gerarAudio, gerarFigurinha
} from './lib.mjs'

const makeWASocket = Baileys.default || Baileys.makeWASocket
const { useMultiFileAuthState, DisconnectReason, downloadMediaMessage } = Baileys

// ================== CONFIGURACAO ==================
const DURACAO_MAXIMA = 10               // segundos de video/audio aproveitados
const LIMITE_FIGURINHA = 900 * 1024     // bytes (o WhatsApp aceita ate ~1 MB)
// ==================================================

const logger = pino({ level: 'silent' })
const pastaAuth = fileURLToPath(new URL('./auth/', import.meta.url))
fs.mkdirSync(pastaAuth, { recursive: true })
const seletorSessao = path.join(pastaAuth, 'sessao-ativa.txt')
const nomeSalvo = fs.existsSync(seletorSessao) ? fs.readFileSync(seletorSessao, 'utf8').trim() : ''
const novoPareamento = process.argv.includes('--parear')
const pastaSessao = novoPareamento
  ? fs.mkdtempSync(path.join(pastaAuth, 'aparelho-'))
  : /^aparelho-[a-z0-9]+$/i.test(nomeSalvo) ? path.join(pastaAuth, nomeSalvo) : pastaAuth
const arquivo = path.join(pastaAuth, 'pedidos-figaudio.json')
const registro = fs.existsSync(arquivo)
  ? JSON.parse(fs.readFileSync(arquivo, 'utf8'))
  : { desde: Math.floor(Date.now() / 1000), pedidos: {} }
let ativo
let fila = Promise.resolve()
let ffmpegDisponivel = await verificarFfmpeg()

function salvar() {
  fs.writeFileSync(arquivo + '.tmp', JSON.stringify(registro))
  fs.renameSync(arquivo + '.tmp', arquivo)
}

aplicarPatchEncode()

function souEu(sock, jid) {
  return Boolean(jid) && [sock.user?.id, sock.user?.lid].some(id =>
    id && Baileys.jidNormalizedUser(id) === Baileys.jidNormalizedUser(jid))
}

async function responderTexto(sock, jid, texto) {
  await sock.sendMessage(jid, { text: texto })
}

async function processarVideo(sock, m, jid) {
  const pasta = fs.mkdtempSync(path.join(os.tmpdir(), 'figsom-'))
  try {
    console.log('Baixando video...')
    const buf = await downloadMediaMessage(m, 'buffer', {}, {
      logger,
      reuploadRequest: sock.updateMediaMessage
    })
    const entrada = path.join(pasta, 'entrada.mp4')
    fs.writeFileSync(entrada, buf)

    if (!(await temAudio(entrada))) {
      await responderTexto(sock, jid, 'Esse video nao tem audio. Mande um video com som para eu fazer a figurinha com som.')
      return
    }

    const total = await duracao(entrada)
    const segundos = Math.max(1, Math.min(DURACAO_MAXIMA, total || DURACAO_MAXIMA))

    console.log(`Convertendo (${segundos.toFixed(1)}s)...`)
    const oggPath = path.join(pasta, 'audio.ogg')
    const webpPath = path.join(pasta, 'figurinha.webp')
    await gerarAudio(entrada, oggPath, segundos)
    const webp = await gerarFigurinha(entrada, webpPath, segundos, LIMITE_FIGURINHA)
    const ogg = fs.readFileSync(oggPath)
    const segundosAudio = Math.max(1, Math.round(await duracao(oggPath)))

    console.log('Enviando arquivos para o WhatsApp...')
    const upload = sock.waUploadToServer
    const fig = await Baileys.prepareWAMessageMedia({ sticker: webp }, { upload, logger })
    const aud = await Baileys.prepareWAMessageMedia(
      { audio: ogg, mimetype: 'audio/ogg; codecs=opus', seconds: segundosAudio },
      { upload, logger }
    )

    const sticker = fig.stickerMessage
    sticker.isAnimated = true
    sticker.width = 512
    sticker.height = 512

    const raw = montarCampo134(sticker, aud.audioMessage)
    const gerarId = Baileys.generateMessageIDV2 || Baileys.generateMessageID
    await sock.relayMessage(jid, { __raw134: raw }, { messageId: gerarId(sock.user.id) })
    console.log('Figurinha com som enviada.')
    return true
  } catch (e) {
    if (ativo !== sock) throw e
    console.log('ERRO:', e)
    await responderTexto(sock, jid, 'Nao consegui fazer a figurinha: ' + (e.message || e))
  } finally {
    fs.rmSync(pasta, { recursive: true, force: true })
  }
}

async function iniciar() {
  const { state, saveCreds } = await useMultiFileAuthState(pastaSessao)
  const sock = makeWASocket({ auth: state, logger })
  let conectadoEm
  salvar()

  function enfileirar(chave) {
    fila = fila.then(async () => {
      const pedido = registro.pedidos[chave]
      if (!pedido || ativo !== sock) return
      if (pedido.video) {
        if (!ffmpegDisponivel) {
          ffmpegDisponivel = await verificarFfmpeg()
          if (!ffmpegDisponivel) {
            if (!pedido.avisouFfmpeg) {
              await responderTexto(sock, pedido.jid, 'Recebi seu !figaudio. O conversor de vídeo está indisponível. Guardei seu pedido para quando o bot reiniciar.')
              pedido.avisouFfmpeg = true
              salvar()
            }
            return
          }
        }
        const video = Baileys.proto.WebMessageInfo.decode(Buffer.from(pedido.video, 'base64'))
        const enviada = await processarVideo(sock, video, pedido.jid)
        if (enviada && pedido.offline) {
          delete pedido.video
          pedido.aviso = true
          salvar()
        }
      } else if (!pedido.aviso) {
        await responderTexto(sock, pedido.jid, 'Responda a um video com !figaudio ou envie o video com !figaudio na legenda.')
      }
      if (pedido.aviso) {
        await responderTexto(sock, pedido.jid, 'Desculpa, estava off, toma sua figurinha!')
      }
      registro.pedidos[chave] = null
      salvar()
    }).catch(e => console.log('Pedido pendente:', e.message))
  }

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr) qrcode.generate(qr, { small: true })
    if (connection === 'open') {
      if (novoPareamento) {
        fs.writeFileSync(seletorSessao + '.tmp', path.basename(pastaSessao))
        fs.renameSync(seletorSessao + '.tmp', seletorSessao)
      }
      conectadoEm = Math.floor(Date.now() / 1000)
      ativo = sock
      for (const [chave, pedido] of Object.entries(registro.pedidos)) {
        if (pedido) enfileirar(chave)
      }
      console.log(nomeBot + ' conectado. Use ' + prefixo('') + 'menu ou !figaudio.')
    }
    if (connection === 'close') {
      if (ativo === sock) ativo = undefined
      const code = lastDisconnect?.error?.output?.statusCode
      console.log('Conexao encerrada. Codigo:', code ?? 'desconhecido')
      if (code === DisconnectReason.connectionReplaced) {
        console.log('Outra conexao assumiu esta sessao. Feche a outra instancia antes de reiniciar.')
      } else if (code === DisconnectReason.loggedOut) {
        console.log('Sessao encerrada no celular. Inicie com --parear para conectar novamente.')
      } else {
        iniciar()
      }
    }
  })

  const recentes = new Set()
  async function receber(messages, historico, aoVivo) {
    for (const m of messages) {
      if (!m.message || !m.key?.id) continue
      const horario = Number(m.messageTimestamp)
      if (historico && !(horario >= registro.desde)) continue

      const conteudo = Baileys.normalizeMessageContent
        ? Baileys.normalizeMessageContent(m.message)
        : m.message
      const texto = conteudo?.videoMessage?.caption ?? conteudo?.imageMessage?.caption ?? conteudo?.extendedTextMessage?.text ?? conteudo?.conversation
      if (typeof texto !== 'string') continue
      const comando = texto.normalize('NFKC').replace(/[\u200b-\u200f\ufeff]/gu, '').trim()
      const jid = m.key.remoteJid
      const emGrupo = jid?.endsWith('@g.us')
      if (!emGrupo && !jid?.endsWith('@s.whatsapp.net') && !jid?.endsWith('@lid')) continue
      const chave = jid + '/' + m.key.id
      const prefix = prefixo(jid)
      const fig = [prefix, '!'].some(p => comando.startsWith(p) && /^\s*fig[aá]udio(?:\s|$)/iu.test(comando.slice(p.length)))
      if (!fig) {
        if (aoVivo && comando.startsWith(prefix) && !recentes.has(chave)) {
          recentes.add(chave)
          if (recentes.size > 4096) recentes.delete(recentes.values().next().value)
          await comandoBase(sock, m, comando).catch(e => console.log('Falha no comando:', e.message))
        }
        continue
      }
      if (!(await podeUsar(sock, m.key))) continue
      if (Object.hasOwn(registro.pedidos, chave)) continue
      console.log('Comando !figaudio recebido.')

      let video = m
      if (!conteudo.videoMessage) {
        const contexto = conteudo.extendedTextMessage?.contextInfo
        const citado = Baileys.normalizeMessageContent(contexto?.quotedMessage)
        if (!citado?.videoMessage || !contexto.stanzaId) {
          video = undefined
        } else {
          const fromMe = souEu(sock, contexto.participant || jid)
          const key = { remoteJid: jid, fromMe, id: contexto.stanzaId }
          if (emGrupo) key.participant = contexto.participant
          video = { key, message: citado }
        }
      }
      registro.pedidos[chave] = {
        jid,
        offline: !conectadoEm || horario < conectadoEm,
        video: video && Buffer.from(Baileys.proto.WebMessageInfo.encode(video).finish()).toString('base64')
      }
      salvar()
      if (ativo === sock) enfileirar(chave)
    }
  }
  sock.ev.on('messages.upsert', ({ messages, type }) => receber(messages, false, type === 'notify').catch(e => console.log(e.message)))
  sock.ev.on('messaging-history.set', ({ messages }) => receber(messages, true, false).catch(e => console.log(e.message)))
  sock.ev.on('group-participants.update', evento => boasVindas(sock, evento).catch(e => console.log(e.message)))
}

if (!ffmpegDisponivel) {
  console.log('FFmpeg ou FFprobe indisponivel. O bot vai receber os pedidos. Para converter, confira a instalacao de Gyan.FFmpeg e reinicie o bot.')
}

console.log('Arquivo do bot:', fileURLToPath(import.meta.url))
iniciar()
