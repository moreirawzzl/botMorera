module.exports = {
name: 'menu',
description: 'Mostra o menu de comandos',
category: 'cmds-aleatorios',
aliases: ['comandos','help'],
async execute(ctx) { return ctx.menu() }
}
